module.exports = ({
   name: "help",
     aliases: ["h", "command", "commands", "cmd", "cmds"],
     type: "messageCreate",
     code: ` 
    $author[Nexus Core Network;$userAvatar[$botID];https://discord.com/oauth2/authorize?client_id=1134121374206660648&scope=bot%20applications.commands&permissions=8]
    $title[Bot Information]
    $color[FDFAF6]
    $description[
> **Developer:** [demonic1594\\](https://discord.com/users/$botOwnerID)
> **Bot Prefix:** \` %, ' \`
> **Commands:** \`$commandCount[messageCreate]\`

- **About**
> A multipurpose bot that includes a variety of multi-functional and advance commands, features, customizability to make your life easier.]
$timestamp
     `})