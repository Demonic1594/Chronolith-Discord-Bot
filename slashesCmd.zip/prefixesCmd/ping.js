module.exports = ({
     name: "ping",
      type: "messageCreate",
      code: `
    $let[msg;$sendMessage[$channelID;$description[Checking client latency...]
    $color[FDFAF6];true]]
    $let[ping;$ping]
    $wait[1000]
    $function[$editMessage[$channelID;$get[msg];$title[🏓 • Pong!]
    $description[<:Ping:1193050550644781136> **Client Latency:** \`$get[ping]ms\`
<:List:1193049903027474492> **Roundtrip:** \`$math[$executionTime-1000]ms\`]
    $color[FDFAF6] $timestamp]]`
})