module.exports = ({
    name: "update",
     aliases: ["reload", "updatecommands"],
     type: "messageCreate",
     code: `
    $onlyForUsers[;$botOwnerID]

    $let[count;$commandCount]
    $updateCommands
    $let[add;$sub[$commandCount;$get[count]]]
 
    $color[FDFAF6]
    $description[Successfully updated all commands.]

    $addActionRow
    $addButton[1;Added: $get[add];Success;✔️;true]
    $addButton[2;Total: $commandCount;Secondary;📃;true]
`})