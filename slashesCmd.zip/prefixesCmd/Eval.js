module.exports = ({
    name: "eval",
      aliases: ["ev", "execute", "exec"],
      type: "messageCreate", 
      code: `
   $if[$authorID==$botOwnerID;
   $eval[$message;true]]
`})